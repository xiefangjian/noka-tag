/*------------------------------------------------------
| noka image upload v1.0 www.97521.com                 |
| rebin 2014-11-28                                     |
|-----------------------------------------------------*/
var nimageUpload = Class.create({
    version: '1.0',
    initialize : function(cfg) {
    	this.id=cfg.id; //id
    	this.name=cfg.name;
    	this.dvid=cfg.id+'_div';
    	this.value=cfg.value;
    	this.filesize=cfg.filesize;
    	this.uid=cfg.uid;
    	this.isdel=cfg.isdel;
    	this.type=cfg.type;
    	this.idreadio=cfg.idreadio;
    	this.onchange=cfg.onchange;
    	this.textsun=cfg.textsun;
    	this.title=cfg.title;
    	this.rurl=cfg.rurl;
    	this.width=cfg.width;
    	this.height=cfg.height;
    	this.utype=cfg.utype;
    	this.sessionid=cfg.sessionid;
    	this.nokatag_image_poet=cfg.nokatag_image_poet;
    	this.nokatag_image_poeter=cfg.nokatag_image_poeter;
    	this.nokatag_image_msg=cfg.nokatag_image_msg;
    },
    show : function(){
    	var self = this;
    	var body=$(self.dvid);//显示对象
    	body.innerHTML=self.InputField();
    	self.utilEvent();//加载事件
    	self.initShow();//初始化显示
    },
    
    initShow : function(){
    	var self = this;
    	if(self.value!=''){//初始化值
    		$(self.id).setValue(self.value);
    	}
    },
    //------------------录入框------------------------------------------------------
    InputField : function(){
    	var self = this;
    	var idx = 0;//
    	var html=[];
    	html[idx++]='<table id="'+self.id+'_table" title="'+self.title+'">';
    	html[idx++]='<tr>';
    	if('2'==self.utype || '3'==self.utype){//显示flash
	    	var purl=self.rurl+'/nokatag/nokatag_uploadfile/file'+self.id+'.fs';
	    	var pars='url='+purl+'&sessionid='+self.sessionid+'&fln='+self.id+'.jpg&type='+self.type+'&resu='+self.id+'_resufunction&reo='+self.id+'_reofunction&erro=ff&labe='+self.nokatag_image_poet+'&width='+self.width+'&height='+self.height;
	    	html[idx++]='<td style="cursor: pointer;border-right:1px dotted red;border-bottom:1px dotted red;border-left:1px dotted red;border-top:1px dotted red;" width="'+self.width+'" height="'+self.height+'" align="center" valign="middle">';
	    	html[idx++]='<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="'+self.width+'" height="'+self.height+'" id="'+self.id+'_poe" align="middle">';
	    	html[idx++]='<param name="allowScriptAccess" value="sameDomain"/>';
	    	html[idx++]='<param name="movie" value="'+self.rurl+'/nokatag/file/upload/cas.swf?'+pars+'"/>';
	    	html[idx++]='<param name="quality" value="high"/>';
	    	html[idx++]='<param name="bgcolor" value="#ffffff"/>';
	    	html[idx++]='<param name="swLiveConnect" value="true"/>'; 
	    	html[idx++]='<param name="wmode" value="transparent"/>';
	    	html[idx++]='<embed src="'+self.rurl+'/nokatag/file/upload/cas.swf?'+pars+'" quality="high" bgcolor="#ffffff" width="'+self.width+'" height="'+self.height+'" name="'+self.id+'_poe" id="'+self.id+'_poe" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"  wmode="transparent"/>'; 
	    	html[idx++]='</object>';
	    	html[idx++]='</td>';
    	}
    	if('2'!=self.utype){
    		html[idx++]='<td style="cursor:pointer;border-right:1px dotted red;border-bottom:1px dotted red;border-left:1px dotted red;border-top:1px dotted red;" width="'+self.width+'" height="'+self.height+'" id="image_'+self.id+'" align="center" valign="middle">';
    	}else{
    		html[idx++]='<td style="border-right:1px dotted red;border-bottom:1px dotted red;border-left:1px dotted red;border-top:1px dotted red;" width="'+self.width+'" height="'+self.height+'" id="image_'+self.id+'" align="center" valign="middle">';
    	}
    	html[idx++]=self.nokatag_image_poeter;
		html[idx++]='</td>'; 
		html[idx++]='<td style="display: none;">'; 
    	html[idx++]='<input type="hidden"  id="'+self.id+'" name="'+self.name+'" value="'+self.value+'"/>';
    	html[idx++]='</td>';
    	html[idx++]='</tr>'; 
    	html[idx++]='</table>';
    	return html.join('');
    },
    //-----------------上传form------------------------------------------------------
    formString : function(){
    	var self = this;
    	var idx = 0;//
    	var html=[];
    	html[idx++]='<div style="display: none;"><form  id = "editForm_'+self.id+'"  name = "editForm_'+self.id+'"  method = "post"  action = "'+self.rurl+'/nokatag/file/upload/upload.html" target ="'+self.id+'_boxid_iframe">';
    	html[idx++]='<input type = "text" id = "filesize" name = "filesize" value = "'+self.filesize+'"/>';
    	html[idx++]='<input type = "text" id = "filetypedescription" name = "filetypedescription" value ="images(*.jpg,*.gif,*.png)"/>';
    	html[idx++]='<input type = "text" id = "filetypeextension" name = "filetypeextension" value ="*.jpg;*.gif;*.png"/>';
    	html[idx++]='<input type = "text" id = "sessionid" name = "sessionid" value = "'+self.sessionid+'"/>';
    	html[idx++]='<input type = "text" id = "isdel" name = "isdel" value = "'+self.isdel+'"/>';
    	html[idx++]='<input type = "text" id = "idreadio" name = "idreadio" value = "'+self.idreadio+'"/>';
    	html[idx++]='<input type = "text" id = "type"  name = "type" value ="'+self.type+'"/>';
    	html[idx++]='<input type = "text" id = "onchange" name = "onchange" value = "'+self.onchange+'"/>';
    	html[idx++]='<input type = "text" id = "inputid" name ="inputid" value ="'+self.id+'"/>';
    	html[idx++]='<input type = "text" id = "spanid" name = "spanid" value = "'+self.id+'_spanid"/>';
    	html[idx++]='<input type = "text" id = "tsun"  name ="tsun" value ="'+self.textsun+'"/>';
    	html[idx++]='</form></div>';
    	return html.join('');
    },
    
    //-------------打开上传窗口----------------------------------------------------------
    openUploadWindow : function(){
    	var self = this;
    	NokaBox.box.show({iframe:'about:blank',boxid:self.id+'_boxid',fixed:false,width:575,height:485,openjs:function(){
    		$(self.id+'_boxid_iframe').contentWindow.document.write('<html><head></head><body>'+self.formString()+'</body></html>');
			$(self.id+'_boxid_iframe').contentWindow.document.getElementById('editForm_'+self.id).submit();
    	},closejs:function(){}});
    },
    
    utilEvent : function(){
    	var self = this;
    	//---------------------返回值-----------------------------------------------------
    	$(self.id).uploadRedata = function(fname,fid,frurl,fdurl){
    		try{self.onchange(fname,fid,frurl,fdurl);}catch(e){};//外部onchange事件
    		try{
    			$(self.id).value=fid;
    			if(''==fid){
    				$('image_'+self.id).innerHTML=self.nokatag_image_msg;
    			}else{
    				$('image_'+self.id).innerHTML='<img alt="" src="'+frurl.split(',')[0]+'" width="'+self.width+'" height="'+self.height+'">';
    			}
    		}catch(e){};
    	};
    	//--------------------设置值-----------------------------------------------------
    	$(self.id).setValue = function(v){
    		$(self.id).value = v;
    		var parsv='do=info&fileid='+v+'&sh=3&s=[&e=]';
    		var myAjax = new Ajax.Request(
    				self.rurl+'/nokatag/nokatag_uploadfile/file'+self.id+'.fs',
    				{
    					parameters:parsv,
    					method:'post',
    					onSuccess:function(a){
    						$('image_'+self.id).innerHTML='<img alt="" src="'+a.responseText+'" width="'+self.width+'" height="'+self.height+'">'; 
    					}
    				}
    		);
    	};
    	//---------------------上传文件外部调用方法------------------------------------------
    	$(self.id).uploadFile = function(){
    		self.openUploadWindow();
    	};
    	if('1'==self.utype || '3'==self.utype){
    		$(self.id+'_table').observe('click', function() {
            	self.openUploadWindow();
            });
    	}
    },
    urlvalue : function(urlstr,names){
    	return decodeURI(urlstr.toQueryParams()[names]);
    }
});