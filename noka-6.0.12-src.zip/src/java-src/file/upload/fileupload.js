/*------------------------------------------------------
| noka file upload v1.0 www.97521.com                  |
| rebin 2014-11-28                                     |
|-----------------------------------------------------*/
var nfileupload = Class.create({
    version: '1.0',
    initialize : function(cfg) {
    	this.id=cfg.id; //id
    	this.name=cfg.name;
    	this.dvid=cfg.id+'_sDiv';
    	this.value=cfg.value;
    	this.filesize=cfg.filesize;
    	this.filetypedescription=cfg.filetypedescription;
    	this.filetypeextension=cfg.filetypeextension;
    	this.uid=cfg.uid;
    	this.isdel=cfg.isdel;
    	this.type=cfg.type;
    	this.idreadio=cfg.idreadio;
    	this.showtype=cfg.showtype;
    	this.onchange=cfg.onchange;
    	this.readonly=cfg.readonly;
    	this.noShow=cfg.noShow;
    	this.textsun=cfg.textsun;
    	this.title=cfg.title;
    	this.rurl=cfg.rurl;
    	this.sessionid=cfg.sessionid;
    	this.width = cfg.width;
    	this.allownull = cfg.allownull;
    },
    show : function(){
    	var self = this;
    	var body=$(self.dvid);//显示对象
    	body.innerHTML=self.InputField();
    	self.utilEvent();//加载事件
    	self.initShow();//初始化显示
    	self.onChangeColor();
    	self.PreLoding();
    },
    
    initShow : function(){
    	var self = this;
    	//----------------------------
    	if(self.noShow){
    		$(self.id+'_spanid').hied();//隐藏
    	}else if(self.readonly){
    		$(self.id+'_spanid').show();//显示内容
    	}else{
    		$(self.id+'_spanid').show();//显示内容
    	}
    	if(self.value!=''){//初始化值
    		$(self.id).setValue(self.value);
    	}
    },
    //------------------录入框------------------------------------------------------
    InputField : function(){
    	var self = this;
    	var idx = 0;//
    	var html=[];
    	html[idx++] ='<div id="'+self.id+'_div" class="selectfile-dropdownchecklist" style="float:left;cursor: pointer;width:'+self.width+'px">';
    	if(self.value==''){
    		html[idx++]='<span id="'+self.id+'_msg" style="float:left;">'+self.title+'</span>';
    	}
    	html[idx++]='<input type="hidden"  id="'+self.id+'" name="'+self.name+'" value="'+self.value+'"/>';
    	html[idx++]='<span id="'+self.id+'_spanid" style="display:none;float:left;margin:0 auto;"></span></div>';
    	if(!self.allownull){
         	html[idx++] = '<div style="float:left;color: red;">*</div>';
         	html[idx++] = '<div style="float:left;"><img style="display:none;vertical-align:middle" id="'+self.id+'_img" src="'+self.rurl+'/nokatag/formcheck/images/exclamation.gif"></img></div>';
         }
    	return html.join('');
    },
    //-----------------上传form------------------------------------------------------
    formString : function(){
    	var self = this;
    	var idx = 0;//
    	var html=[];
    	html[idx++]='<div style="display: none;"><form  id = "editForm_'+self.id+'"  name = "editForm_'+self.id+'"  method = "post"  action = "'+self.rurl+'/nokatag/file/upload/upload.html" target ="'+self.id+'_boxid_iframe">';
    	html[idx++]='<input type = "text" id = "filesize" name = "filesize" value = "'+self.filesize+'"/>';
    	html[idx++]='<input type = "text" id = "filetypedescription" name = "filetypedescription" value ="'+self.filetypedescription+'"/>';
    	html[idx++]='<input type = "text" id = "filetypeextension" name = "filetypeextension" value ="'+self.filetypeextension+'"/>';
    	html[idx++]='<input type = "text" id = "sessionid" name = "sessionid" value = "'+self.sessionid+'"/>';
    	html[idx++]='<input type = "text" id = "isdel" name = "isdel" value = "'+self.isdel+'"/>';
    	html[idx++]='<input type = "text" id = "idreadio" name = "idreadio" value = "'+self.idreadio+'"/>';
    	html[idx++]='<input type = "text" id = "type"  name = "type" value ="'+self.type+'"/>';
    	html[idx++]='<input type = "text" id = "onchange" name = "onchange" value = "'+self.onchange+'"/>';
    	html[idx++]='<input type = "text" id = "inputid" name ="inputid" value ="'+self.id+'"/>';
    	html[idx++]='<input type = "text" id = "spanid" name = "spanid" value = "'+self.id+'_spanid"/>';
    	html[idx++]='<input type = "text" id = "tsun"  name ="tsun" value ="'+self.textsun+'"/>';
    	html[idx++]='</form></div>';
    	return html.join('');
    },
    
    //-------------打开上传窗口----------------------------------------------------------
    openUploadWindow : function(){
    	var self = this;
    	NokaBox.box.show({iframe:'about:blank',boxid:self.id+'_boxid',fixed:false,width:575,height:485,openjs:function(){
    			$(self.id+'_boxid_iframe').contentWindow.document.write('<html><head></head><body>'+self.formString()+'</body></html>');
    			$(self.id+'_boxid_iframe').contentWindow.document.getElementById('editForm_'+self.id).submit();
    	},closejs:function(){}});
    },
    
    utilEvent : function(){
    	var self = this;
    	//---------------------返回值-----------------------------------------------------
    	$(self.id).uploadRedata = function(fname,fid,frurl,fdurl){
    		try{self.onchange(fname,fid,frurl,fdurl);}catch(e){};//外部onchange事件
    		try{
    			$(self.id).value=fid;
    			var sbn='';
    			$(self.id+'_div').setStyle({width:'auto'});//宽度设成自动
    			if(1==self.showtype){//显示方式，1,为下载，2，为查看，0，为没有操作
    				for(var i=0;i<fdurl.split(',').length;i++){
    					sbn=sbn+'<a target="_black" href="'+fdurl.split(',')[i]+'"/>'+fname.split(',')[i]+'</a>';
    				}
    				$(self.id+'_spanid').innerHTML=sbn;
    			}
    			if(2==self.showtype){//查看
    				for(var i=0;i<fdurl.split(',').length;i++){
    					sbn=sbn+'[<a id="'+self.id+'_'+i+'_alink" target="_black" href="#"/>'+fname.split(',')[i]+'</a>]';
    				}
    				$(self.id+'_spanid').innerHTML=sbn;
    			}
    			if(0==self.showtype){//没有操作
    				$(self.id+'_spanid').innerHTML=fname;
    			}
    			//--------------------------------------------------------
    			if(fid==''){
    				$(self.id+'_msg').innerHTML=self.title;
    			}else{
    				$(self.id+'_msg').innerHTML='';
    			}
    			//--------------------------------------------------------
    			var dwidth = $(self.id+'_div').getWidth();
    			if(fid==''){
    				$(self.id+'_spanid').innerHTML='';
    				$(self.id+'_div').setStyle({width:self.width+'px'});
    			}else if(dwidth<self.width){
    				$(self.id+'_div').setStyle({width:self.width+'px'});
    			}
    			//------------------------------------------------------
    			$(self.id).veri();
    		}catch(e){};
    	};
    	//--------------------设置值-----------------------------------------------------
    	$(self.id).setValue = function(v){
    		$(self.id).value = v;
    		var parsv='do=info&fileid='+v+'&sh='+self.showtype+'&s=[&e=]';
    		var myAjax = new Ajax.Request(
    				self.rurl+'/nokatag/nokatag_uploadfile/file'+self.id+'.fs',
    				{
    					parameters:parsv,
    					method:'post',
    					onSuccess:function(a){
    						$(self.id+'_spanid').innerHTML=a.responseText;
    					}
    				}
    		);
    	};
    	//---------------------上传文件外部调用方法------------------------------------------
    	$(self.id).uploadFile = function(){
    		self.openUploadWindow();
    	};
    	//-------------------打开上传窗口事件----------------------------------------------
    	$(self.id+'_div').observe('click', function() {
    		if(!self.readonly){
    			self.openUploadWindow();
    		}
        });
    	$(self.id).veri = function(){
    	    if(($(self.id).value.trim().length<1) && !self.allownull){//不能为空
    	    	$(self.id+'_img').show();
    	    	return false;
    	    }
    	    try{$(self.id+'_img').hide();}catch(e){}
    	    return true;
    	};
    },
    onChangeColor : function(){
    	var self = this;
    	var obj = $(self.id+'_div');
    	var sjwidth = obj.getWidth();
        if(sjwidth>self.width){
        	obj.setStyle({width:(self.width-18)+'px'});
        	self.width = (self.width-18);
        }
        
    	obj.observe('mousemove',function(){
     		self.setSelectStyle(obj);
     	});
         obj.observe('mouseout',function(event){
         	var element = event.element();
         	setTimeout(function(){
                 	self.setNoSelectStyle(obj);
             }, 500);
         });
    },
    //----------选种状态-----------------------
    setSelectStyle : function(obj){
    	var self = this;
    	obj.setStyle({borderColor:'#5794bf',backgroundImage:'url('+self.hImg.src+')'});
    },
    //-----------未选种状态-------------------
    setNoSelectStyle : function(obj){
    	var self = this;
    	obj.setStyle({borderColor:'#AFAFAF',backgroundImage:'url('+self.mImg.src+')'});
    },
    //-----------预加载图片-------------------
    PreLoding : function(){
    	var self = this;
    	self.hImg = new Image(); 
    	self.mImg = new Image();
    	self.hImg.src=self.rurl+'/nokatag/org/noka/select/drodpfile_hover.png';
    	self.mImg.src=self.rurl+'/nokatag/org/noka/select/drodpfile.png';
    	NBackgroundImageCache();
    }
});