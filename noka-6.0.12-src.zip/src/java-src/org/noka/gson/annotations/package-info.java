/**
 * This package provides annotations that can be used with {@link org.noka.gson.Gson}.
 * 
 * @author Inderjeet Singh, Joel Leitch
 */
package org.noka.gson.annotations;