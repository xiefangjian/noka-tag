//<textarea id="ac" name="ac" style="width:560px;height:200px;"></textarea><script type="text/javascript">	</script>
/*----------------------------------------------
| noka select v1.0 www.97521.com                 |
| rebin 2014-01-15                             |
|---------------------------------------------*/
var nhtmledit = Class.create({
    version: '1.0',
    initialize : function(id) {
    	this.id=id; //id
    },
    show : function(){
    	this.initHtml();
    	this.eventHtml();
    },
    initHtml:function(){
    	var self = this;
    	WYSIWYG.attach(self.id);
    	try{
    		setInterval(function(){
    			WYSIWYG.gettextp(self.id);
    		},100);
    	}catch(e){};
    },
    eventHtml:function(){
    	var self = this;
    	//----------设置值-------------------------
    	$(self.id).setValue = function(v){
           try{
        	   WYSIWYG.settexts(self.id,v);
           }catch(e){}
    	};
    	//-----------获取值------------------------
    	$(self.id).getValue = function(){
            try{
            	WYSIWYG.gettexts(self.id);
            }catch(e){}
     	};
     	//-----------插入值------------------------
     	$(self.id).insertHTML = function(v){
            try{
            	WYSIWYG.insertHTML(v,self.id);
            }catch(e){}
     	};
     	
    }
});