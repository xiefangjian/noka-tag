/**********************************************************************
	Version: FreeRichTextEditor.com Version 1.00.
	License: http://creativecommons.org/licenses/by/2.5/
	Description: Configuration File.
	Author: Copyright (C) 2006  Steven Ewing
**********************************************************************/

// Width of the rich text editor.
rteWidth = "100%";
// Name of the IFRAME (content editor).
rteName = "freeRTE";
// Name of the hidden form field.
rteFormName = "freeRTE_content";
// Height of the rich text editor.
rteHeight = "300px";
// Path to the images folder.
rteImagePath = "${rootpath}/${htmlEdit.rteImagePath}";
// Path to insert form popup.
rteHTMLPathInsertForm = "${rootpath}/nokatag/htmledit/popups/insert_form.html";
// Path to insert checkbox popup.
rteHTMLPathInsertCheckbox = "${rootpath}/nokatag/htmledit/popups/insert_checkbox.html";
// Path to insert radio button popup.
rteHTMLPathInsertRadiobutton = "${rootpath}/nokatag/htmledit/popups/insert_radiobutton.html";
// Path to insert text area popup.
rteHTMLPathInsertTextArea = "${rootpath}/nokatag/htmledit/popups/insert_textarea.html";
// Path to insert submit button popup.
rteHTMLPathInsertSubmit = "${rootpath}/nokatag/htmledit/popups/insert_submit.html";
// Path to insert image submit button popup.
rteHTMLPathInsertImageSubmit = "${rootpath}/nokatag/htmledit/popups/insert_image_submit.html";
// Path to reset form button popup.
rteHTMLPathInsertReset = "${rootpath}/nokatag/htmledit/popups/insert_reset.html";
// Path to insert hidden form field popup.
rteHTMLPathInsertHidden = "${rootpath}/nokatag/htmledit/popups/insert_hidden.html";
// Path to insert password field popup.
rteHTMLPathInsertPassword = "${rootpath}/nokatag/htmledit/popups/insert_password.html";
// Path to insert text field popup.
rteHTMLPathInsertText = "${rootpath}/nokatag/htmledit/popups/insert_text.html";
// Path to insert table popup.
rteHTMLPathInsertTable = "${rootpath}/nokatag/htmledit/popups/insert_table.html";
// Path to edit table properties popup.
rteHTMLPathEditTable = "${rootpath}/nokatag/htmledit/popups/edit_table.html";
// Path to insert link popup.
rteHTMLPathInsertLink = "${rootpath}/nokatag/htmledit/popups/insert_link.html";
// Path to edit link popup.
rteHTMLPathEditLink = "${rootpath}/nokatag/htmledit/popups/edit_link.html";
// Path to insert image popup.
rteHTMLPathInsertImage = "${rootpath}/nokatag/htmledit/popups/insert_image.html";
// Format Menu (H1, H2, H3 etc etc).
rteFormat = ${htmlEdit.rteFormat};
// Font Face Menu (Arial, Verdana etc etc).
rteFontFace = ${htmlEdit.rteFontFace};
// Font Size Menu (1, 2, etc etc).
rteFontSize = ${htmlEdit.rteFontSize};
// Font Color Menu.
rteFontColor = ${htmlEdit.rteFontColor};
// Bold Text Button.
rteBold = ${htmlEdit.rteBold};
// Italicize Text Button.
rteItalic = ${htmlEdit.rteItalic};
// Underline Text Button.
rteUnderline = ${htmlEdit.rteUnderline};
// Strikethrough Text Button.
rteStrikeThrough = ${htmlEdit.rteStrikeThrough};
// Left Justify Button.
rteLeftAlign = ${htmlEdit.rteLeftAlign};
// Center Justify Button.
rteCenterAlign = ${htmlEdit.rteCenterAlign};
// Right Justify Button.
rteRightAlign = ${htmlEdit.rteRightAlign};
// Full Justify Button.
rteFullAlign = ${htmlEdit.rteFullAlign};
// Insert Horizontal Rule Button.
rteHorizontalRule = ${htmlEdit.rteHorizontalRule};
// Superscript Text Button.
rteSuperscript = ${htmlEdit.rteSuperscript};
// Subscript Text Button.
rteSubscript = ${htmlEdit.rteSubscript};
// Insert Hyperlink Button.
rteLink = ${htmlEdit.rteLink};
// Remove Hyperlink Button.
rteUnlink = ${htmlEdit.rteUnlink};
// Insert Image Button.
rteImages = ${htmlEdit.rteImages};
// Remove Formatting Button.
rteRemoveFormat = ${htmlEdit.rteRemoveFormat};
// Table Formatting Buttons.
rteTables = ${htmlEdit.rteTables};
// Insert an ordered list Button.
rteOrderedList = ${htmlEdit.rteOrderedList};
// Insert an unordered list Button.
rteUnorderedList = ${htmlEdit.rteUnorderedList};
// Indent Button.
rteIndent = ${htmlEdit.rteIndent};
// Outdent Button.
rteOutdent = ${htmlEdit.rteOutdent};
// Undo Button.
rteUndo = ${htmlEdit.rteUndo};
// Redo Button.
rteRedo = ${htmlEdit.rteRedo};
// Cut, Copy & Paste Buttons.
rteCutCopyPaste = ${htmlEdit.rteCutCopyPaste};
// Insert form button.
rteInsertForm = ${htmlEdit.rteInsertForm};
// Insert checkbox button.
rteInsertCheckbox = ${htmlEdit.rteInsertCheckbox};
// Insert radio button.
rteInsertRadio = ${htmlEdit.rteInsertRadio};
// Insert textarea.
rteInsertTextArea = ${htmlEdit.rteInsertTextArea};
// Insert submit button.
rteInsertSubmit = ${htmlEdit.rteInsertSubmit};
// Insert image submit button.
rteInsertImageSubmit = ${htmlEdit.rteInsertImageSubmit};
// Insert reset button.
rteInsertReset = ${htmlEdit.rteInsertReset};
// Insert hidden field.
rteInsertHidden = ${htmlEdit.rteInsertHidden};
// Insert password field.
rteInsertPassword = ${htmlEdit.rteInsertPassword};
// Insert text field.
rteInsertTextField = ${htmlEdit.rteInsertTextField};
// Print Rich Text Area Content.
rtePrint = ${htmlEdit.rtePrint};
// Select All of Rich Text Area Content.
rteSelectAll = ${htmlEdit.rteSelectAll};
// Spell Checker.
rteSpellCheck = ${htmlEdit.rteSpellCheck};
// Show Preview Button.
rtePreviewMode = ${htmlEdit.rtePreviewMode};
// Show Code Edit Button.
rteCodeMode = ${htmlEdit.rteCodeMode};
// Show Design Mode Button.
rteDesignMode = ${htmlEdit.rteDesignMode}