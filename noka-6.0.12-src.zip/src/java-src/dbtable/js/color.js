//var sMenuBgColor="#D4D0C8";
var sMenuBgColor="#D4D0C8";				//�˵��ı���ɫ
var sMenuBorderLight="#FFFFFF";			//�˵��߿�� �ϱ߿� �� ��߿� ����ɫ
var sMenuBorderDark="#666666";			//�˵��߿�� �±߿� �� �ұ߿� ����ɫ
var sMenuTextColor="#000000";			//�˵��������ɫ
var sMenuTextBgColor="";				//�˵�����ı���ɫ
var sMenuDisableTextColor="#B9B9B9";	//û�����õĲ˵���������ɫ
var sMenuSTextColor="#FFFFFF";			//�˵���ѡ�����������ɫ
var sMenuSTextBgColor="#006699";		//�˵���ѡ��������屳��ɫ
var bBodyClickDisable=false;
var oSelectedTr=null;
var oPopupMenu=null;
var oOverTr=null;

var tableid=null;
//---------------л�������---------------
function sortables_init(indexname,obje) {
    // Find all tables with class sortable and make them sortable
	var OBJec=null;
    if (!document.getElementsByTagName) return;
    tbls = document.getElementsByTagName("tr");
	var ti=0;
    for (;ti<tbls.length;ti++) {
        thisTbl = tbls[ti];
		//((' '+thisTbl.className+' ').indexOf(indexname) != -1) && (thisTbl.id)
        if (thisTbl.className==indexname) {
			//alert(thisTbl.className);
            OBJec = thisTbl;
			break;
        }
    }
	//alert(ti+"  "+tbls.length);
	if(ti>=tbls.length){
		OBJec = obje;
	}
	return OBJec;
}
//--------------л�������-------------

function fnChangeTrColor(index,obj,checkbox)
{	
	var isc = document.getElementById(checkbox).checked;
	var oObj = null;
	if(tr2.length==undefined){
		oObj = tr2;
	}
	else{
		oObj = tr2(index);
		oObj=sortables_init(index,oObj);
		
	}
	
	if(isc){
		 document.getElementById(checkbox).checked=false;
		var objs=document.getElementById(obj);
		if(objs.chkall.checked)
			objs.chkall.checked = false;
	}
	//------------------------------
	if(!isc){
		document.getElementById(checkbox).checked=true;
	}
	fnInvertColor(oObj,oObj);
}
//----------------------------------------
function checkbox(vars){
	if(vars.checked){
		 vars.checked=false;
	}else if(!vars.checked){
		vars.checked=true;
	}
}
function fnInvertColor(oSTr,oSFont)
{	
		oSTr.style.backgroundColor=sMenuSTextBgColor;//���ѡ�е���ɫ
		oSFont.style.color=sMenuSTextColor;
}


function tr2_onmouseover(index,checkbox) {
	//
	
	var obj = null;
	if(tr2.length==undefined){
		obj = tr2;
	}
	else{
		obj = tr2(index);
		obj=sortables_init(index);
	}
	if (document.getElementById(checkbox).checked)
	{
		return;
	}
	//tr2(index).style.backgroundColor="#C0D8FE";
	//tr2(index).style.color="#000000";
	obj.style.backgroundColor="#C0D8FE";
	obj.style.color="#000000";
}

function tr2_onmouseout(index,checkbox) {
	var obj = null;
	if(tr2.length==undefined){
		obj = tr2;
	}
	else{
		obj = tr2(index);
		obj=sortables_init(index,obj);	
	}
	if (document.getElementById(checkbox).checked)
	{
		return;
	}
	//tr2(index).style.backgroundColor="";
	//tr2(index).style.color="";
	
	obj.style.backgroundColor="";
	obj.style.color="";
}

function tr1_onmouseover(index) {
	tr1(index).style.backgroundColor="#E4E4E4";
	tr1(index).style.color="#000000";
}

function tr1_onmouseout(index) {
	if (0 == index % 2){
		tr1(index).style.backgroundColor="";
		tr1(index).style.color="black";
	}
	else
	{
		tr1(index).style.backgroundColor="#D5D5D5";
		tr1(index).style.color="black";
	}
}




function tr3_onmouseover(index) {
	tr3(index).style.backgroundColor="#D6F3D6";
	tr3(index).style.color="#000000";
}

function tr3_onmouseout(index) {
	if (0 == index % 2){
		tr3(index).style.backgroundColor="";
		tr3(index).style.color="black";
	}
	else
	{
		tr3(index).style.backgroundColor="#ebf3f5";
		tr3(index).style.color="black";
	}
}

//-------------------------------------
 function script(sts,celln){
  	var tablen = document.getElementById(sts);
	tablen.id="mytablettt";
	for(var i=1;i<tablen.rows.length;i++){
		if(tablen.rows.item(i).cells.item(celln).innerText==tablen.rows.item(i-1).cells.item(celln).innerText){
			SpanGrid(tablen,celln);
		}
	}
	
	
  }  
function SpanGrid(tabObj,colIndex)
{
 if(tabObj != null)
 {
  var i,j;
  var intSpan;
  var strTemp;
  for(i = 0; i < tabObj.rows.length; i++)
  {
   intSpan = 1;
   strTemp = tabObj.rows[i].cells[colIndex].innerText;
   for(j = i + 1; j < tabObj.rows.length; j++)
   {
    if(strTemp == tabObj.rows[j].cells[colIndex].innerText)
    {
     intSpan++;
     tabObj.rows[i].cells[colIndex].rowSpan  = intSpan;
     tabObj.rows[j].cells[colIndex].style.display = "none";
    }
    else
    {
     break;
    }
   }
   i = j - 1;
  }
 }
}


//-----------------------------------
function chkAll(obj){
	var obj=document.getElementById(obj)
	for (i=0;i<obj.elements.length;i++){
		var e = obj.elements[i];
		if (e.type=="checkbox" && e.name != "chkall"){
				e.checked = obj.chkall.checked;
				if(e.checked)
					fnInvertColor(e.parentNode.parentNode,e.parentNode.parentNode);
				else{
					e.parentNode.parentNode.style.color="";
					e.parentNode.parentNode.style.backgroundColor="";
					}
			}
	}
}
//-----------------------------------------------------------
function subtablese(subtableid,subtableimagepathsn,subtableimage){
	if(document.getElementById(subtableid).style.display=='none'){
		document.getElementById(subtableid).style.display='block';
		document.getElementById(subtableimage).innerHTML='<img src="'+subtableimagepathsn+'/nokatag/minu_tales.gif" width="16" height="16" border="0" />';
		}
	else if(document.getElementById(subtableid).style.display=='block'){
		document.getElementById(subtableid).style.display='none';
		document.getElementById(subtableimage).innerHTML='<img src="'+subtableimagepathsn+'/nokatag/plus_table.gif" width="16" height="16" border="0" />';
		}
}

