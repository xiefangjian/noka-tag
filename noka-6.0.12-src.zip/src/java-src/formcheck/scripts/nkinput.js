/*----------------------------------------------
| noka input v1.0 www.97521.com                 |
| rebin 2014-01-20                             |
|---------------------------------------------*/
var ninput = Class.create({
    version: '1.0',
    initialize : function(cfg) {
    	this.id=cfg.id; //id
    	this.rurl=cfg.rurl;
    	this.icosrc=cfg.rurl+'/nokatag/formcheck/images/exclamation.gif';
    	this.input = $(cfg.id);
    	this.allownull=cfg.allownull;//是否允许为空
    	this.ico=$(cfg.id+'_img');
    	this.div=$(cfg.id+'_div');
    	this.chtype=cfg.chtype;//验证内型chtype js|server|regex
    	this.verification=cfg.verification;//验证内容
    	this.veriSuccess = cfg.allownull;
    	this.ajaxchtype = true;// 是否正在执行ajva验证
    },
    initinput : function(){
    	this.initIco();
    	this.initMsg();
    	this.InputVerEvent();
    	this.msgShowHide();
    	this.initObjCht();
    	this.onChangeColor();
    },
    //---------初始化ico------------------
    initIco : function(){
	   this.ico.src = this.icosrc;
	   this.ico.setStyle({verticalAlign:'middle'});
	   this.ico.hide();
	   this.input.setStyle({verticalAlign:'middle'});
    },
    //---------初始化msgdiv--------------
    initMsg : function(){
    	this.div.setStyle({display:'block',background:'#FFFFFF',border:'solid 1px #FF0000',zIndex:'9999',padding:'5px 5px 5px'});
    	this.div.absolutize();
    	this.div.hide();
    },
    //--------初始化验证-----------------
    initObjCht : function(){
    	var self = this;
    	$(self.id).veri = function(){
    		var val = $(self.id).value;
    		self.chVeris(val);//验证
    		if(!self.veriSuccess)
    			self.ico.show();
	    	return self.veriSuccess;
    	};
    	$(self.id).setValue = function(value,ch){
    		$(self.id).value = value;//设置值
    		if(typeof ch == 'undefined'){
    			self.chVeris(value);//验证
    		}else{
    			self.veriSuccess=ch;
    			if(!ch){
    				$(self.id+'_img').show();
    			}else if(ch){
    				$(self.id+'_img').hide();
    			}
    				
    		}
    	};
    },
    //---------增加验证事件---------------
    InputVerEvent : function(){
    	 var self = this;
    	 self.input.observe('blur',function(){//失失焦点时验证其值
    		 self.chVeris(this.value);
    	});
    },
    chVeris : function(va){
    	var self = this;
    	if((va.trim().length<1) && !self.allownull){//不允许为空
			 self.ico.show();
			 self.veriSuccess=false;
		 }else if(va.trim().length>0){//有输入内容
			 if(''!=self.verification){
				 var chend = false;//验证结果
   			 if('js'==self.chtype)
   				 chend=self.chInputJs(va);
   			 else if('regex'==self.chtype){
   				 chend=self.chInputRegex(va);
   			 }else if('server'==self.chtype)
   				 self.chInputServer(va);
   			 if(!chend){
   				 self.ico.show();
   				 self.veriSuccess=false;
   			 }else{
   				 self.ico.hide();
   				 self.veriSuccess=true;
   			 }
			 }else{
				 self.ico.hide();
				 self.veriSuccess=true;
			 }
		 }else{//没有输入内容，可以为空
			 self.ico.hide();
			 self.veriSuccess=true;
		 }
    },
    //--------regex------------------------
    chInputRegex : function(value){
    	var issc = true;
    	var regu = "^" + this.verification + "$";
    	var re = new RegExp(regu);
    	return re.test(value);
    },
    //---------自定义js验证-----------------
    chInputJs : function(value){
    	return this.verification(value);
    },
    //---------服务端验证-------------------
    chInputServer : function(value){
    	var self = this;
    	var idx = 0;//
    	var parsv=[];
    	parsv[idx++]='fun='+self.verification;
    	parsv[idx++]='&thisvalue='+value;
    	new Ajax.Request(self.rurl+'/nokatag/ajax/inputtextcheck'+self.id+'.itck', {
    		method:'post',
            parameters: parsv.join(''),
            onSuccess: function(response) {
            	var v = response.responseText;
            	if('1'==v){//成功
            		self.ico.hide();
            		self.veriSuccess = true;
            	}else{//失败
            		self.ico.show();
            		self.veriSuccess=false;
            	}
            	self.ajaxchtype = false;//验证完成
            },
            onFailure : function(transport) {
            	self.ajaxchtype = false;//验证完成
            }
    	});
    },
    //-------------空验证------------------
    chInputNull : function(value){
    	if (''==value)
    		return true;
    	var regu = "^[ ]+$";
    	var re = new RegExp(regu);
    	return re.test(value);
    },
    //--------消息提示显示、隐藏------------
    msgShowHide : function(){
    	var self = this;
   	 	self.ico.observe('mousemove',function(){//失失焦点时验证其值
   	 		if(self.ico.visible){//图标可见
   	 			self.div.absolutize();
   	 			self.div.style.top=self.ico.positionedOffset().top+self.ico.offsetHeight;//
   	 			self.div.style.left=self.ico.positionedOffset().left+self.ico.offsetWidth;
   	 			self.div.show();
   	 		}
   	 	});
   	 	self.ico.observe('mouseout',function(event){
	   	 	if(self.div.visible){//图标可见
		 			self.div.hide();
		 	}
   	 	});
    },
    onChangeColor : function(){
    	var self = this;
    	var obj = $(self.id+'_sdDiv');
    	obj.observe('mousemove',function(){
     		self.setSelectStyle(obj);
     	});
    	
         obj.observe('mouseout',function(event){
         	var element = event.element();
         	setTimeout(function(){
                 	self.setNoSelectStyle(obj);
             }, 500);
         });
    },
    //----------选种状态-----------------------
    setSelectStyle : function(obj){
    	obj.setStyle({borderColor:'#5794bf'});
    },
    //-----------未选种状态-------------------
    setNoSelectStyle : function(obj){
    	obj.setStyle({borderColor:'#AFAFAF'});
    }
});