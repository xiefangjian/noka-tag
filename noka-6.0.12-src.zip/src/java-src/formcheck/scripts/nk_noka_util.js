//----------from对像---------------------
var NKFormHtml = Class.create({
    version: '1.0',
    initialize : function(dbModel) {
    	this.target = dbModel.target;//表单id
    	this.rurl=dbModel.rurl;
    	this.onSuccess=dbModel.onSuccess;//成功时的回调方法
    	this.onFailure = dbModel.onFailure;//失败时回调方法
    	this.onsubmit = dbModel.onsubmit;//提交时调用方法
    },
    //--------------表单初始化------------------------------------------------------
    show : function(){
    	var self = this;
    	self.EventForm();
    },
    FormSubmit : function(furl){
    	var idx=0;
    	var pars=[];
    	var self=this;
    	var b=true;
    	$$('#'+self.target+' input,select,textarea').each(function(alink,index) {
    		//-------------验证-------------------------------------------------
    		try{
    			if(b)
    				b=alink.veri();
    			else
    				alink.veri();
    		}catch(e){}
    		//------------------------------------------------------------------
    		if(alink.type=='checkbox' || alink.type=='radio'){
    			if(alink.checked)
    				pars[idx++]='&'+alink.name+'='+alink.value;//alert(alink.name);
    		}else{
    			pars[idx++]='&'+alink.name+'='+encodeURIComponent(alink.value);//alert(alink.name);
    		}
		});
    	if(b){//验证通过提交
    			self.showLoad();//显示加载提示
    			if(typeof furl != "undefined"){
    				$(self.target).action=furl;
    			}
    	    	new Ajax.Request($(self.target).action, {
	            parameters: pars.join(''),
	            method:'post',
	            onSuccess: function(response) {
	            	self.closeInfo();//关闭消息
	            	try{
	            		self.onSuccess(response);
	            	}catch(e){}
	            },
	            onFailure : function(response) {
	            	self.closeInfo();//关闭消息
	            	self.onFailure(response);
	            }
	    	});
    	}
    },
    //---------------验证表单------------------------------------------------------
    CheckFormData : function(){
    	var self = this;
    	var b=true;
    	$$('#'+self.target+' input,select,textarea').each(function(alink,index) {
    		//-------------验证-------------------------------------------------
    		try{
    			if(b)
    				b=alink.veri();
    			else
    				alink.veri();
    		}catch(e){}
		});
    	return b;
    },
    //--------------加载事件-------------------------------------------------------
    EventForm : function(){
    	var self = this;
    	$(self.target).showInfo=function(a,b){//显示信息
    		self.showInfo(a,b);
    	};
    	$(self.target).showErro=function(a,b){//显示错误信息
    		self.showErro(a,b);
    	};
    	$(self.target).showLoad=function(){//显示等待信息
    		self.showLoad();
    	};
    	$(self.target).closeInfo=function(){//关闭显示信息
    		self.closeInfo();
    	};
    	$(self.target).ajaxSubmit=function(furl){//ajax方式提交数据
    		if(typeof self.onsubmit != "undefined"){
    			if(self.onsubmit()){//外部方法返回true
    				self.FormSubmit(furl);
    			}
    		}else{
    			self.FormSubmit(furl);
    		}
    	};
    	$(self.target).observe('submit',function(event){//在提交数据的时候进行验证
    		var isSubmit = false;
    		if(typeof self.onsubmit != "undefined"){
    			isSubmit=self.onsubmit();//自定义
    		}
    		if(isSubmit){
    			isSubmit = self.CheckFormData();
    		}
    		if(!isSubmit)
    			Event.stop(event);//有错误时停止提交
    		else
    			return true;
        });
    },
    //--------------显示加载提示----------------------------------------------------
    showLoad : function(){
    	var self = this;
    	var postition = self.divMsg();
		NokaBox.box.show({html:'<img alt="" src="'+self.rurl+'/nokatag/tablegrid/images/mtg-loader.gif"/>load...',fixed:false,close:false,mask:false,boxid:'success',top:postition.top,left:postition.left});//显示等待消息
    },
    //--------------显示消息----------------------------------------------------
    showInfo : function(htmls,ahid){
    	var self = this;
    	if(typeof ahid=="undefined")
    		ahid=2;
    	var postition = self.divMsg();
    	NokaBox.box.show({html:htmls,fixed:false,close:false,mask:false,autohide:ahid,boxid:'success',top:postition.top,left:postition.left});//显示消息
    },
    //--------------显示错了消息-------------------------------------------------
    showErro : function(htmls,ahid){
    	var self = this;
    	if(typeof ahid=="undefined")
    		ahid=2;
    	var postition = self.divMsg();
		NokaBox.box.show({html:htmls,fixed:false,close:false,mask:false,autohide:ahid,boxid:'error',top:postition.top,left:postition.left});//显示错误消息
    },
    //--------------关闭消息----------------------------------------------------
    closeInfo : function(){
    	NokaBox.box.hide();
    },
    //---------------div定位---------------------------------------------------
    divMsg : function(){
    	var self = this;
    	var postition={top:0,left:0};
    	try{
	    	var msgDiv = $(self.target+'_msg');
	    	if(msgDiv!=undefined){
	    		postition.top = msgDiv.positionedOffset().top+msgDiv.offsetHeight+5;
	    		postition.left=msgDiv.positionedOffset().left+msgDiv.offsetWidth+5;
	    	}
    	}catch(e){}
    	return postition;
    }
});
//=====================input msg=========================
function  noka_DLSH89UY76HJH_msgshow(tid,url,msg,isb){
	var t = document.getElementById(tid+'_image'); 
	var p = document.getElementById(tid+'_msg'); 
	if(''==p.innerHTML){
    	var idx=0;
    	var html=[];
    	var img=url+'/nokatag/formcheck/images/error-tip-corners.gif';
    	html[idx++]='<table  border="0" cellpadding="0" cellspacing="0"   id="table_id">';
		html[idx++]='<tr>';
		html[idx++]='  <td style="background:url('+img+') no-repeat 0 0px; width:6px; height:6px;"></td>';
		html[idx++]='  <td style="background:url('+img+') repeat-x  0 -12px;height:6px; " ></td>';
		html[idx++]='  <td style="background:url('+img+') no-repeat  -494px  0px;height:6px; width:6px;"></td>';
		html[idx++]=' </tr>';
		html[idx++]=' <tr>';
		html[idx++]=' <td  style="background:url('+img+') repeat-y  0px -25px;height:6px; "></td>';
		html[idx++]=' <td "+msgBgPrave+" style="background:#FFFFFF">';
		html[idx++]=' 		<table border="0" cellpadding="0" cellspacing="0">';
		html[idx++]=' 		<tr>';
		html[idx++]=' 		<td valign="top" width="20px">';
		html[idx++]='<img src="'+url+'/nokatag/formcheck/images/exclamation.gif" width="16" height="16" align="absmiddle"/>&nbsp;&nbsp;';
		html[idx++]='</td><td id="si_erromesage" >';
		html[idx++]=msg;
		html[idx++]='</td></tr></table>';
		html[idx++]='  </td>';
		html[idx++]=' <td style="background:url('+img+') no-repeat  -494px  -24px;height:6px; width:6px;"></td>';
		html[idx++]=' </tr>';
		html[idx++]=' <tr>';
		html[idx++]='  <td style="background:url('+img+') repeat-y  0px -6px;height:6px;"></td>';
		html[idx++]=' <td style="background:url('+img+') repeat-x  0px -18px;height:6px;"></td>';
		html[idx++]=' <td style="background:url('+img+') no-repeat  -494px -6px;height:6px;"></td>';
		html[idx++]='</tr>';
		html[idx++]='</table>';
		p.innerHTML=html.join('');
	}
	if(isb){
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
		p.style.left=(left1 - left2)+16;
		p.style.top=(top1 + t.offsetHeight - top2);
		p.style.display = 'block';
	}else{
		p.style.display = 'none';
	}
}
function noka_SDF5SDFL23JLSDGSD7DSMQS324SDSDFN_issuc(tid,isb){
	if(isb){//通过验证
		document.getElementById(tid).className=document.getElementById(tid).tempclass;
		document.getElementById(tid+'_image').style.display = 'none';
		document.getElementById(tid+'_check').value='no';
	}else{//未通过验证
		document.getElementById(tid).className='noka_inputclassname_LJKSDFJKLSDF8234ZX12890BJKSDFSDF_erro';
		document.getElementById(tid+'_image').style.display = 'block';
		document.getElementById(tid+'_check').value='yes';
	}
}
//===============获取绝对位置=================================
function noka_tag_LJKFS24783SFJKL_getTop(el){
	var top = el.offsetTop;
		if (el.offsetParent != null) 
			top += noka_tag_LJKFS24783SFJKL_getTop(el.offsetParent);
	return top;
}
function noka_tag_LJKFS24783SFJKL_getLeft(el) {
	var left = el.offsetLeft;
	if (el.offsetParent != null) 
		left += noka_tag_LJKFS24783SFJKL_getLeft(el.offsetParent);
	return left;
}
//==============textarea=====================================
function nokata_DSFLKJ_gbcount(total,used,remain,myid,msg)
{
	 var max;
	 max = total.value;
	 if (myid.value.length > max) {
		 myid.value = myid.value.substring(0,max);
		 used.value = max;
		 remain.value = 0;
		 alert(msg);
	 }else {
		 used.value = myid.value.length;
		 remain.value = max - used.value;
	 }
}
//==============select=====================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv(tid){ 
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus(tid);
		var th = $(tid); 
		var t = $(tid+'_show'); 
		var p = $(tid+'_div'); 
	if($(tid+'_div').style.display =='none'){
		$(tid+'_show').style.color='#FFFFFF';
		$(tid+'_div').style.width = $(tid+'_listtable').offsetWidth;
		$(tid+'_show').style.backgroundColor ='#000066';
		var values = $(tid).value;
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist(tid,values);
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
		$(tid+'_div').style.left=(left1 - left2);
		$(tid+'_div').style.top=(top1 + t.offsetHeight - top2)+3;
		$(tid+'_div').style.display = 'block';
	}else{
		$(tid+'_div').style.display = 'none';
		$(tid+'_show').style.color='';
		$(tid+'_show').style.backgroundColor = '';
	}
	
}
// ==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist(ids,values){ 
 	var iss = false; 
	for(i=0;i<$(ids+'_listsize').value;i++){ 
		if($(ids+'_value_'+i).value==values){
			noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+i),ids,i);
			iss = true;
		}
	}
	if(!iss){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_0'),ids,0);
	}
}
//=================隐藏列表=============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_enddiv(tid,onbl){
	if($(tid+'_input_isonedit').value=='false' ){
		$(tid+'_show').style.color='';
		$(tid+'_show').style.backgroundColor = '';
	}
	if($(tid+'_div_isonedit').value=='true' || $(tid+'_button_isonedit').value=='true' || $(tid+'_div_isonedit').value=='true' ){
	}else{
		$(tid+'_div').style.display = 'none';
		onbl($(tid));
	}
}

//===========改变列表的每行颜色=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp(obj,ids,idn){
for(i=0;i<$(ids+'_listsize').value;i++){
		$(ids+'_list_'+i).style.backgroundColor = '#FFFFFF';
		$(ids+'_list_'+i).style.color='#000000';
		$(ids+'_isselected_'+i).value = 'false'; 
	}
	obj.style.backgroundColor = '#000066';
	obj.style.color='#FFFFFF';
	$(ids+'_isselected_'+idn).value = 'true';
}
//===============选择列表数据=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clickhtmlvaluep(obj,ids,idn,oncha){
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus(ids);
	$(ids).value = $(ids+'_value_'+idn).value;
	$(ids+'_show').value = $(ids+'_text_'+idn).value;
	$(ids+'_div').style.display = 'none';
	$(ids+'_show').style.backgroundColor = '#000066';
	$(ids+'_show').style.color='#FFFFFF';
	oncha($(ids+'_show'),$(ids));
}
//================查找列表数据项================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_listdata(obj,events){
  _e = events;
  var e = _e.keyCode ? _e.keyCode : _e.which;
	if(e==13 || e==38 || e==40){
	if($(obj.id+'_div').style.display == 'block'){
		for(ns=0;ns<$(obj.id+'_listsize').value;ns++){
			if($(obj.id+'_isselected_'+ns).value=='true'){
				if(e==13){//回车
					obj.value = $(obj.id+'_value_'+ns).value;
					$(obj.id+'_show').value = $(obj.id+'_text_'+ns).value;
					$(obj.id+'_div').style.display = 'none';
					break;
				}else if(e==38){//向上
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup(obj.id,ns);
					break;
				}else if(e==40){//向下
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd(obj.id,ns);
					break;
				}
			}
		}
	  }else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv(obj.id);
	  };
	}else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb(obj);
		for(i=0;i<$(obj.id+'_listsize').value;i++){
			var valuen = $(obj.id+'_value_'+i).value;
			valuen = valuen.substring(0,obj.value.length);
			if(valuen==obj.value){
				noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(obj.id+'_list_'+i),obj.id,i);
				noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdivkeyup(obj.id);
				break;
			}
		}

	}
}
//===========录入傎时显示列表===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdivkeyup(tid){
	var values = $(tid+'_show').value;
	var t = $(tid+'_show'); 
	var p = $(tid+'_div'); 
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_kup(tid,values);
	$(tid+'_div').style.width = $(tid+'_listtable').offsetWidth;
	$(tid+'_div').style.left=(left1 - left2);
	$(tid+'_div').style.top=(top1 + t.offsetHeight - top2)+3;
	$(tid+'_div').style.display = 'block';
}
//=========方向上键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup(ids,n){
	b = n-1;
	if(b>=0 && b<$(ids+'_listsize').value){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+b),ids,b);
	}
}
//=========方向下键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd(ids,n){
	b = n+1;
	if(b>=0 && b<$(ids+'_listsize').value){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+b),ids,b);
	}
}
//==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_kup(ids,values){
	for(i=0;i<$(ids+'_listsize').value;i++){
		if($(ids+'_list_'+i).value==values){
			alert(i);noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+i),ids,i);
		}
	}
}
//=========失去焦点===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus(ids){
	$(ids+'_but').blur();
	$(ids+'_show').focus();
}
//========清空样式===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb(obj){
	$(obj.id+'_show').style.color='';
	$(obj.id+'_show').style.backgroundColor = '';
}
//********treeselect********************************
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv_mult(tid){ 
	var t = $(tid+'_show'); 
	var th = $(tid); 
	var p = $(tid+'_div'); 
	if($(tid+'_div').style.display =='none'){
		$(tid+'_show').style.color='#FFFFFF';
		$(tid+'_show').style.backgroundColor = '#000066';
		var values = th.value;
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
		$(tid+'_div').style.left=(left1 - left2);
		$(tid+'_div').style.top=(top1 + t.offsetHeight - top2)+3;
		$(tid+'_div').style.display = 'block';
	}else{
		$(tid+'_div').style.display = 'none';
		t.style.color='';
		t.style.backgroundColor = '';
	}
}
//=================隐藏列表=============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_enddiv_mult(tid,onbl){
	if($(tid+'_but_isonedit').value=='false' ){
		$(tid+'_show').style.color='';
		$(tid+'_show').style.backgroundColor = '';
	}
	if($(tid+'_show_isonedit').value=='true' || $(tid+'_but_isonedit').value=='true' || $(tid+'_div_isonedit').value=='true' ){
	}else{
		$(tid+'_div').style.display = 'none';
		onbl($(tid+'_show'));
	}
}

//===============选择列表数据=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clickhtmlvaluep_mult(ids,val,sval,oncha){
	$(ids+'_show').style.backgroundColor = '#000066';
	$(ids+'_show').style.color='#FFFFFF';
	$(ids+'_show').focus();
	$(ids+'_div').style.display ='none';
	$(ids+'_show').value=sval;
	$(ids).value=val;
	oncha($(ids+'_show'),$(ids));
}
//================查找列表数据项================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_listdata_mult(obj,events){
  _e = events;
  var e = _e.keyCode ? _e.keyCode : _e.which;
	if(e==13 || e==38 || e==40){
	if($(obj.id+'_div').style.display == 'block'){
		for(s=0;s<$(obj.id+'_listsize').value;s++){
			if($(obj.id+'_list_'+s).isselected=='true'){
				if(event.keyCode==13){//回车
					obj.value = $_mult(obj.id+'_list_'+s).innerHTML;
					$(obj.id+'_div').style.display = 'none';
					break;
				}else if(event.keyCode==38){//向上
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup_mult(obj.id,s);
					break;
				}else if(event.keyCode==40){//向下
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd_mult(obj.id,s);
					break;
				}
			}
		}
	  }else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv_mult(obj.id);
	  };
	}
}

//=========方向上键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup_mult(ids,n){
	b = n-1;
	if(b>=0 && b<$(ids+'_show').listsize){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+b),ids);
	}
}
//=========方向下键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd_mult(ids,n){
	b = n+1;
	if(b>=0 && b<$(ids+'_show').listsize){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+b),ids);
	}
}
//==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_kup_mult(ids,values){
	for(i=0;i<$(ids+'_show').listsize;i++){
		if($(ids+'_list_'+i).innerHTML==values){
			noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp($(ids+'_list_'+i),ids);
		}
	}
}
//=========失去焦点===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus_mult(ids){
	$(ids+'_but').blur();
	$(ids+'_show').focus();
}
//========清空样式===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb_mult(obj){
	obj.style.color='';
	obj.style.backgroundColor = '';
}
//=======单选框====================================
function noka_tag_FDLKJ4543BSFDKLJ4598734_checkclick_mult(vars){
	if(vars.checked){
	 	vars.checked=false;
	}else if(!vars.checked){
		vars.checked=true;
	}
}
//*****************selectinput********************
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv_si(tid){ 
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus_si(tid);
	var t = $(tid); 
	var p = $(tid+'_div'); 
	if($(tid+'_div').style.display =='none'){
		$(tid).style.color='#FFFFFF';
		$(tid+'_div').style.width = $(tid+'_listtable').offsetWidth;
		$(tid).style.backgroundColor = '#000066';
		var values = $(tid).value;
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_si(tid,values);
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
		$(tid+'_div').style.left=(left1 - left2);
		$(tid+'_div').style.top=(top1 + t.offsetHeight - top2)+3;
		$(tid+'_div').style.display = 'block';
	}else{
		$(tid+'_div').style.display = 'none';
		$(tid).style.color='';
		$(tid).style.backgroundColor = '';
	}
}
// ==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_si(ids,values){ 
 	var iss = false; 
	for(i=0;i<$(ids+'_listsize').value;i++){ 
		if($(ids+'_list_'+i).innerHTML==values){
			noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si($(ids+'_list_'+i),ids,i);
			iss = true;
		}
	}
	if(!iss){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si($(ids+'_list_0'),ids,0);
	}
}
//=================隐藏列表=============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_enddiv_si(tid,onbl){
	if($(tid+'_but_isonedit').value=='false' ){
		$(tid).style.color='';
		$(tid).style.backgroundColor = '';
	}
	if($(tid+'_isonedit').value=='true' || $(tid+'_but_isonedit').value=='true' || $(tid+'_div_isonedit').value=='true' ){
	}else{
		$(tid+'_div').style.display = 'none';
		onbl($(tid));
	}
}

//===========改变列表的每行颜色=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si(obj,ids,ins){
	for(i=0;i<$(ids+'_listsize').value;i++){
		$(ids+'_list_'+i).style.backgroundColor = '#FFFFFF';
		$(ids+'_list_'+i).style.color='#000000';
		$(ids+'_list_isselected_'+i).value = 'false'; 
	}
	obj.style.backgroundColor = '#000066';
	obj.style.color='#FFFFFF';
	$(ids+'_list_isselected_'+ins).value = 'true';
}
//===============选择列表数据=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clickhtmlvaluep_si(obj,ids,onch){
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus_si(ids);
	$(ids).value = obj.innerHTML;
	$(ids+'_div').style.display = 'none';
	$(ids).style.backgroundColor = '#000066';
	$(ids).style.color='#FFFFFF';
	try{onch($(ids));}catch(e){};
}
//================查找列表数据项================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_listdata_si(obj,events){
  _e = events;
  var e = _e.keyCode ? _e.keyCode : _e.which;
	if(e==13 || e==38 || e==40){
	if($(obj.id+'_div').style.display == 'block'){
		for(s=0;s<$(obj.id+'_listsize').value;s++){
			if($(obj.id+'_list_isselected_'+s).value=='true'){
				if(e==13){//回车
					obj.value = $(obj.id+'_list_'+s).innerHTML;
					$(obj.id+'_div').style.display = 'none';
					break;
				}else if(e==38){//向上
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup_si(obj.id,s);
					break;
				}else if(e==40){//向下
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd_si(obj.id,s);
					break;
				}
			}
		}
	  }else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv_si(obj.id);
	  };
	}else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb_si(obj);
		for(i=0;i<$(obj.id+'_listsize').value;i++){
			var valuen = $(obj.id+'_list_'+i).innerHTML;
			valuen = valuen.substring(0,obj.value.length);
			if(valuen==obj.value){
				noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si($(obj.id+'_list_'+i),obj.id,i);
				noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdivkeyup_si(obj.id);
				break;
			}
		}
	}
}
//===========录入傎时显示列表===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdivkeyup_si(tid){
	var values = $(tid).value;
	var t = $(tid); 
	var p = $(tid+'_div'); 
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_kup_si(tid,values);
	$(tid+'_div').style.width = $(tid+'_listtable').offsetWidth;
	$(tid+'_div').style.left=(left1 - left2);
	$(tid+'_div').style.top=(top1 + t.offsetHeight - top2)+3;
	$(tid+'_div').style.display = 'block';
}
//=========方向上键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup_si(ids,n){
	b = n-1;
	if(b>=0 && b<$(ids+'_listsize').value){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si($(ids+'_list_'+b),ids,b);
	}
}
//=========方向下键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd_si(ids,n){
	b = n+1;
	if(b>=0 && b<$(ids+'_listsize').value){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si($(ids+'_list_'+b),ids,b);
	}
}
//==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_kup_si(ids,values){
	for(i=0;i<$(ids+'_listsize').value;i++){
		if($(ids+'_list_'+i).innerHTML==values){
			noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_si($(ids+'_list_'+i),ids,i);
		}
	}
}
//=========失去焦点===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus_si(ids){
	$(ids+'_but').blur();
	$(ids).focus();
}
//========清空样式===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb_si(obj){
	obj.style.color='';
	obj.style.backgroundColor = '';
}
//***************************************************
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv_mult_musi(tid){ 
	noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus_mult_musi(tid);
		var t = $(tid+'_show'); 
		var th = $(tid); 
		var p = $(tid+'_div'); 
	if($(tid+'_div').style.display =='none'){
		$(tid+'_show').style.color='#FFFFFF';
		$(tid+'_div').style.width = $(tid+'_listtable').offsetWidth;
		$(tid+'_show').style.backgroundColor = '#000066';
		var values = th.value;
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_mult_musi(tid,values);
		var top1 = noka_tag_LJKFS24783SFJKL_getTop(t);
		var left1 = noka_tag_LJKFS24783SFJKL_getLeft(t);
		var top2 = 0;
		var left2 = 0;
		if (p.offsetParent != null) {
			top2 = noka_tag_LJKFS24783SFJKL_getTop(p.offsetParent);
			left2 = noka_tag_LJKFS24783SFJKL_getLeft(p.offsetParent);
		}
		$(tid+'_div').style.left=(left1 - left2);
		$(tid+'_div').style.top=(top1 + t.offsetHeight - top2)+3;
		$(tid+'_div').style.display = 'block';
	}else{
		$(tid+'_div').style.display = 'none';
		t.style.color='';
		t.style.backgroundColor = '';
	}
}
//==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_mult_musi(ids,values){ 
	for(i=0;i<$(ids+'_listsize').value;i++){ 
	 	$(ids+'_checkbox_'+i).checked=false;
	}
	for(i=0;i<$(ids+'_listsize').value;i++){ 
	 for(s=0;s<$(ids).value.split(',').length;s++){
	 	if(values.split(',')[s]==$(ids+'_checkbox_'+i).value){
	 		$(ids+'_checkbox_'+i).checked=true;
	 	}
	 }
	}
}
//=================隐藏列表=============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_enddiv_mult_musi(tid,onbcl){
	if($(tid+'_but_isonedit').value=='false' ){
		$(tid+'_show').style.color='';
		$(tid+'_show').style.backgroundColor = '';
	}
	if($(tid+'_show_isonedit').value=='true' || $(tid+'_but_isonedit').value=='true' || $(tid+'_div_isonedit').value=='true' ){
	}else{
		$(tid+'_div').style.display = 'none';
		onbcl($(tid+'_show'));
	}
}
//===========改变列表的每行颜色=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_mult_musi(obj,ids){
	for(i=0;i<$(ids+'_listsize').value;i++){
		$(ids+'_list_'+i).style.backgroundColor = '#FFFFFF';
		$(ids+'_list_'+i).style.color='#000000';
		$(ids+'_list_'+i+'_isselected').value= 'false'; 
	}
	obj.style.backgroundColor = '#000066';
	obj.style.color='#FFFFFF';
	$(obj.id+'_isselected').value = 'true';
}
//===============选择列表数据=============
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clickhtmlvaluep_mult_musi(obj,ids,checkids,onchan){
	$(ids+'_show').style.backgroundColor = '#000066';
		if($(checkids).checked)
			$(checkids).checked=false;
		else
			$(checkids).checked=true;
		$(ids+'_show').style.color='#FFFFFF';
		$(ids+'_show').focus();
	var strvaue='';
	var showvaue='';
	for(i=0;i<$(ids+'_listsize').value;i++){ 
		if($(ids+'_checkbox_'+i).checked){
			strvaue+=','+$(ids+'_checkbox_'+i).value;
			showvaue+=','+$(ids+'_list_'+i+'_text').value;
		}
	}
	 $(ids+'_show').value=showvaue.substring(1);
	 $(ids).value=strvaue.substring(1);
	 onchan($(ids+'_show'),$(ids));
}
//================查找列表数据项================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_listdata_mult_musi(obj,events){
  _e = events;
  var e = _e.keyCode ? _e.keyCode : _e.which;
	if(e==13 || e==38 || e==40){
	if($(obj.id+'_div').style.display == 'block'){
		for(s=0;s<$(obj.id+'_listsize').value;s++){
			if($(obj.id+'_list_'+s+'_isselected').value=='true'){
				if(e==13){//回车
					obj.value = $_mult(obj.id+'_list_'+s).innerHTML;
					$(obj.id+'_div').style.display = 'none';
					break;
				}else if(e==38){//向上
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup_mult_musi(obj.id,s);
					break;
				}else if(e==40){//向下
					noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd_mult_musi(obj.id,s);
					break;
				}
			}
		}
	  }else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdiv_mult_musi(obj.id);
	  };
	}else{
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb_musi(obj);
		for(i=0;i<$(obj.id+'_listsize').value;i++){
			var valuen = $(obj.id+'_list_'+i).innerHTML;
			valuen = valuen.substring(0,obj.value.length);
			if(valuen==obj.value){
				noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_mult_musi($(obj.id+'_list_'+i),obj.id);
				noka_tag_FKLSD231B7821GFASDHG237SDHJ_showdivkeyup_mult_musi(obj.id);
				break;
			}
		}
	}
}
//=========方向上键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpup_mult_musi(ids,n){
	b = n-1;
	if(b>=0 && b<$(ids+'_listsize').value){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_musi($(ids+'_list_'+b),ids);
	}
}
//=========方向下键==========================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_snbpd_mult_musi(ids,n){
	b = n+1;
	if(b>=0 && b<$(ids+'_listsize').value){
		noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_musi($(ids+'_list_'+b),ids);
	}
}
//==========按名字选中列表项============================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_selectedlist_kup_mult_musi(ids,values){
	for(i=0;i<$(ids+'_listsize').value;i++){
		if($(ids+'_list_'+i).innerHTML==values){
			noka_tag_FKLSD231B7821GFASDHG237SDHJ_bgcolorp_musi($(ids+'_list_'+i),ids);
		}
	}
}
//=========失去焦点===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_bluerfocus_mult_musi(ids){
	$(ids+'_but').blur();
	$(ids+'_show').focus();
}
//========清空样式===================================
function noka_tag_FKLSD231B7821GFASDHG237SDHJ_clearb_mult_musi(obj){
	obj.style.color='';
	obj.style.backgroundColor = '';
}
//=======单选框====================================
function noka_tag_FDLKJ4543BSFDKLJ4598734_checkclick_mult_musi(vars){
	if(vars.checked){
	 	vars.checked=false;
	}else if(!vars.checked){
		vars.checked=true;
	}
}