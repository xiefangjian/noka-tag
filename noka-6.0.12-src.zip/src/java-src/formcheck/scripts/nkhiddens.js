/*----------------------------------------------
| noka hiddens v1.0 www.97521.com                 |
| rebin 2015-03-06                             |
|---------------------------------------------*/
var nhiddens = Class.create({
    version: '1.0',
    initialize : function(cfg) {
    	this.json=cfg.json;
    	this.id = cfg.id;
    	this.debug=cfg.debug || false;
    },
    show : function(){
    	this.initHiddens();
    	this.hiddensEvent();
    },
    //---------初始化--------------------------------
    initHiddens : function(){
    	var json = this.json;
    	var idx = 0;//
    	var html=[];
    	var bodyHtml=$(this.id);
    	html[idx++]='<div>';
    	for(var i=0;i<json.length;i++){
    		html[idx++]='<input  type="'+(this.debug?'text':'hidden')+'"  '+(json[i].id==undefined?'':'id="'+json[i].id+'"')+'" name="'+json[i].name+'" value="'+(json[i].value==undefined?'':json[i].value)+'" />';
    	}
    	html[idx++]='</div>';
    	bodyHtml.innerHTML=html.join('');
    },
    hiddensEvent : function(){
    	var self = this;
    	//-----------geValue---------------------
    	$(self.id).getValue = function(){
    		var idx = 0;//
        	var vals=[];
    		for(var i=0;i<json.length;i++){
    			vals[idx++]=$(json[i].id).value; 
        	}
    		return vals;
    	};
    }
});