/*----------------------------------------------
| noka input v1.0 www.97521.com                 |
| rebin 2014-08-14                             |
|---------------------------------------------*/
var ntextarea = Class.create({
    version: '1.0',
    initialize : function(cfg) {
    	this.id=cfg.id; //id
    	this.rurl=cfg.rurl;//根路径
    	this.charsize = cfg.charsize;//字数
    	this.lang_1=cfg.lang_1;
    	this.lang_2=cfg.lang_2;
    	this.lang_3=cfg.lang_3;
    	this.lang_4=cfg.lang_4;
    	this.lang_5=cfg.lang_5;
    },
    show : function(){
    	this.textarCreat();
    	this.TextareaEvent();
    },
    //-----------------创建-----------------------------
    textarCreat : function(){
    	var idx = 0;
        var html = [];
        var self = this;
        var bodyHtml=$(self.id+'_infoDiv');
        html[idx++] = self.lang_1;//
        html[idx++] = '<input disabled  name="total" id="'+self.id+'_intotal"  value="'+self.charsize+'" style="border:none; background:#fff;color:#c1c1c1; width:30px;">';
        html[idx++] = self.lang_2;//已用字数：
        html[idx++] = '<input disabled  name="used" id="'+self.id+'_inused" value="0"  style="border:none; background:#fff;color:#c1c1c1; width:30px;">';
        html[idx++] = self.lang_3;//剩余字数：
        html[idx++] = '<input disabled  name="remain" id="'+self.id+'_inremain"  value="'+self.charsize+'"  style="border:none; background:#fff;color:#c1c1c1; width:30px;">';
        bodyHtml.innerHTML=html.join('');
    },
    TextareaEvent : function(){
    	var self = this;
    	var obj = $(self.id);
    	obj.observe('keydown',function(a){
    		self.UpdateInfo();
    	});
    	obj.observe('KeyUp',function(a){
    		self.UpdateInfo();
    	});
    	obj.observe('mousemove',function(){
     		self.setSelectStyle(obj);
     	});
        obj.observe('mouseout',function(event){
         	var element = event.element();
         	setTimeout(function(){
                 self.setNoSelectStyle(obj);
             }, 500);
         });
        $(self.id).setValue = function(value,ch){
    		$(self.id).value = value;//设置值
    	};
    },
    UpdateInfo : function(){
	 var max;
	 var self = this;
	 var total = $(self.id+'_intotal');
	 var used = $(self.id+'_inused');
	 var remain = $(self.id+'_inremain');
	 var myid = $(self.id);
	 var msg = self.lang_4+self.charsize+self.lang_5;
	 max = total.value;
	 if (myid.value.length > max) {
		 myid.value = myid.value.substring(0,max);
		 used.value = max;
		 remain.value = 0;
		 alert(msg);
	 }else {
		 used.value = myid.value.length;
		 remain.value = max - used.value;
	 }
    },
   //----------选种状态-----------------------
    setSelectStyle : function(obj){
    	obj.setStyle({borderColor:'#5794bf'});
    },
    //-----------未选种状态-------------------
    setNoSelectStyle : function(obj){
    	obj.setStyle({borderColor:'#AFAFAF'});
    }
});