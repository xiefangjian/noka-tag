var $lang={
errAlertMsg: "${org_nokatag_tagjava_datetime_1}",
aWeekStr: ["${org_nokatag_tagjava_datetime_2}"],
aLongWeekStr:["${org_nokatag_tagjava_datetime_3}"],
aMonStr: ["${org_nokatag_tagjava_datetime_4}"],
aLongMonStr: ["${org_nokatag_tagjava_datetime_5}"],
clearStr: "${org_nokatag_tagjava_datetime_6}",
todayStr: "${org_nokatag_tagjava_datetime_7}",
okStr: "${org_nokatag_tagjava_datetime_8}",
updateStr: "${org_nokatag_tagjava_datetime_9}",
timeStr: "${org_nokatag_tagjava_datetime_10}",
quickStr: "${org_nokatag_tagjava_datetime_11}", 
err_1: '${org_nokatag_tagjava_datetime_12}'
};