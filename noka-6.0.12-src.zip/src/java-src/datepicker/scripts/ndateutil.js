/*----------------------------------------------
| noka select v1.0 www.97521.com               |
| rebin 2014-08-11                             |
|---------------------------------------------*/
var ndateutil = Class.create({
    version: '1.0',
    initialize : function(cfg) {
    	this.cfg = cfg;					//配置信息
    	this.id=cfg.id; //id
    	this.allownull = cfg.allownull;//为true表示可以为空
    	this.hImg;
    	this.mImg;
    	this.prave = cfg.prave;
    },
    show : function(){
    	var idx = 0;
        var html = [];
        var self = this;
        var bodyHtml = $(self.id+'_dadiv');
        this.PreLoding();
        if(!self.allownull){
        	html[idx++] = '<div style="float:left;color: red;">*</div>';
        	html[idx++] = '<img style="display:none;vertical-align:middle" id="'+self.id+'_img" src="'+self.cfg.rurl+'/nokatag/formcheck/images/exclamation.gif"></img>';
        }
        bodyHtml.innerHTML=html.join('');
        self.extEvent();
    },
    extEvent : function(){
    	var self = this;
    	$(self.id+'_sdDiv').observe('click',function(){//失失焦点时验证其值
    		self.prave.onHideDate =function(){
    			$(self.id).veri();
			};
			self.prave.oncleared=function(){
				$(self.id).veri();
			};
			WdatePicker(self.prave);
    	});
    	$(self.id).observe('blur',function(){//失失焦点时验证其值
    		$(self.id).veri();
    	});
    	var obj = $(self.id+'_sdDiv');
    	$(self.id).veri = function(){
    	    if(($(self.id).value.trim().length<1) && !self.allownull){//不能为空
    	    	$(self.id+'_img').show();
    	    	return false;
    	    }
    	    try{$(self.id+'_img').hide();}catch(e){}
    	    return true;
    	};
    	$(self.id).setValue = function(v){
    		$(self.id).value = v;
    		try{$(self.id+'_img').hide();}catch(e){}
    	};
    	obj.observe('mousemove',function(){
     		self.setSelectStyle(obj);
     	});
         obj.observe('mouseout',function(event){
         	var element = event.element();
         	setTimeout(function(){
                 	self.setNoSelectStyle(obj);
             }, 500);
         });
    },
   //----------选种状态-----------------------
    setSelectStyle : function(obj){
    	var self = this;
    	obj.setStyle({borderColor:'#5794bf',backgroundImage:'url('+self.hImg.src+')'});
    },
    //-----------未选种状态-------------------
    setNoSelectStyle : function(obj){
    	var self = this;
    	obj.setStyle({borderColor:'#AFAFAF',backgroundImage:'url('+self.mImg.src+')'});
    },
    //-----------预加载图片-------------------
    PreLoding : function(){
    	var self = this;
    	self.hImg = new Image(); 
    	self.mImg = new Image();
    	self.hImg.src=self.cfg.rurl+'/nokatag/datepicker/skin/datePicker_hover.png';
    	self.mImg.src=self.cfg.rurl+'/nokatag/datepicker/skin/datePicker.png';
    	try{document.execCommand("BackgroundImageCache", false, true);}catch(e){};
    }
});